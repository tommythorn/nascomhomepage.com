21 November 2003

--- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 

NEWS IN VERSION 2.0:

- 80 columns mode (!) ...it is strongly suggested to use the 48 columns mode, though.
- SCREEN command fixed
- FONT fixed.. there was a nasty shift for the characters above the chr 9fh
- SET, RESET and POINT now work and emulate ECONOGRAPHICS !!
- USR(0) now acts as a generic INKEY$ function; 
	this helps on running many of the machine code calls.
	Sometimes, when the function should wait for a keypress, it is also 
	necessary a little hack in the original program.
	Consider that if no key is pressed the function returns 0.
- KEMPSTON JOYSTICK is used to emulate the cursor keys for USR(0)
- POKE and DOKE do work for the screen address !!!  ...PEEK and DEEK still don't (that will be hard).

--- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- 

Hello,
this is a NASCOM BASIC emulator for the ZX Spectrum 48K.
It permits to run several programs which don't require machine code routines.

The main difference is on the screen size, which permits 24 lines on the Spectrum, 
while it was 16 lines long only on the original machine.

To convert the original programs, use the included cas2zx tool, which converts the
".CAS" files used in the nascom emulators into the well known ".TAP" ones.


To learn more on the NASCOM BASIC you can refer to the original documentation:
http://www.nascomhomepage.com/pdf/Basic.pdf

Most of CAS files I could find on the web are here:
http://www.nascomhomepage.com/index.html



To develop this emulator I used parts of the Z88DK project, expecially the Z80ASM 
assembler and an extract of the ANSI VT emulator (for the 5 bit font handling).
Also the font editor By Marcio Afonso Arimura Fialho has been of help on creating
the proper character set.
Any comment is welcome.


Enjoy,


    Stefano Bodrato  -  stefano.bodrato@pioneerinvest.it
