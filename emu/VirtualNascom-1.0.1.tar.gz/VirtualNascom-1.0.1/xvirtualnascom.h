void xsetup(int, char **);
void xhandleevent(void);
void xputch(int x, int y, unsigned char v);

extern unsigned char keym[9];
Display *dpy;
int  vflag;
