Nascom II Emulator

Version 1.2

1. Hardware

This emulator covers the following hardware items:

Nascom II CPU
Gemini 64K RAM card
Lucas Logic AVC model B
Lucas Logic FDC

2. Required Environment

The software has been tested against  J2SE 1.3.1.  It MAY work
with earlier releases.

3. How To Run

Use the run.bat file to start the emulator.
To start the processor use Execute -> Run

4. General Notes

When starting the emulator has nas-sys 3 loaded and nothing else.  To load roms
use File -> Load File (ROM)  - Uses .nas files
Ordinary programs can be loaded using File -> Load File (RAM) - Uses .nas files
Tape file get read from read.cas and written to write.cas files
You can load / save disk images (double sided) - These are compatable with the
disk images on the web site.

5. Deployment Preferences

The deployment properties file can be used to change some features of the
emulator.

MULTIPROCESSOR=1
set to 1 for multi cpu systems. Places gui and cpu on seperate threads and
increases AVC performance.  Set to 0 if you experience problems on
uni-processor systems.  Seems ok on most systems as set.

ROM_WARNING=0
set to 1 for warnings when attempts to write to ROM occur

KEY_TIME=100
repeat key delay in ms

6. Known Problem Areas

At present you will get a lot of junk in the console window - will be removed
for the final version
The Gemini 64K memory card does not have paging operations supported
Funny effects when running in multiprocessor mode with the grapics under
J2SE 1.4. Not sure why.  Can't find any Swing stuff in the release notes which
point to possible problems.

9. Change Log

1.1 -> 1.2

Keyboard handling much improved.  Should now work with all non UK / US keyboards
Minor performance improvements for graphical output
Better documentation for the Z80 processor core
Z80 register display now has real values on HALT

8. Other Items

The emulator is (c) 2002 Richard Espley - All rights reserved.
Reverse engineering of the code is strictly forbidden - however, if you want the
source, email me, say why you want it and as long as its not a commercial
project, you can have it.  If it is commercial then its Licence time.

What could be simpler ?


richard@espley.net
